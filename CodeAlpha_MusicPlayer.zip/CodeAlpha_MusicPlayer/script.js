let audio = new Audio();
let currentSongIndex = 0;
let songs = [
  { src: "Sooseki.mp3", title: "Sooseki", artist: "Anirudh", image: "Sooseki.jpeg" },
  { src: "Saradaga.mp3", title: "Saradaga Kasepaina", artist: "Radhan", image: "Saradaga.jpg" },
  { src: "Hoyna.mp3", title: "Hoyna Hoyna", artist: "Anirudh", image: "Hoyna.jpg" }
];

let playPauseBtn = document.getElementById("playPause");
let prevBtn = document.getElementById("prev");
let nextBtn = document.getElementById("next");
let progress = document.getElementById("progress");
let currentTimeDisplay = document.getElementById("current-time");
let durationDisplay = document.getElementById("duration");
let volumeControl = document.getElementById("volume");

let songName = document.getElementById("songName");
let artistName = document.getElementById("artistName");
let albumCover = document.getElementById("albumCover");

function loadSong(songIndex) {
  audio.src = songs[songIndex].src;
  songName.textContent = songs[songIndex].title;
  artistName.textContent = songs[songIndex].artist;
  albumCover.src = songs[songIndex].image;
  audio.load();
}

function playPause() {
  if (audio.paused) {
    audio.play();
    playPauseBtn.innerHTML = `<i class="fa fa-pause"></i>`;
  } else {
    audio.pause();
    playPauseBtn.innerHTML = `<i class="fa fa-play"></i>`;
  }
}

function prevSong() {
  currentSongIndex = (currentSongIndex - 1 + songs.length) % songs.length;
  loadSong(currentSongIndex);
  audio.play();
}

function nextSong() {
  currentSongIndex = (currentSongIndex + 1) % songs.length;
  loadSong(currentSongIndex);
  audio.play();
}

audio.addEventListener("timeupdate", () => {
  let currentTime = audio.currentTime;
  let duration = audio.duration;

  let currentMinutes = Math.floor(currentTime / 60);
  let currentSeconds = Math.floor(currentTime % 60);
  let durationMinutes = Math.floor(duration / 60);
  let durationSeconds = Math.floor(duration % 60);

  currentTimeDisplay.textContent = `${currentMinutes}:${currentSeconds < 10 ? '0' : ''}${currentSeconds}`;
  durationDisplay.textContent = `${durationMinutes}:${durationSeconds < 10 ? '0' : ''}${durationSeconds}`;

  progress.value = (currentTime / duration) * 100;
});

progress.addEventListener("input", (e) => {
  let value = e.target.value;
  let duration = audio.duration;
  audio.currentTime = (value / 100) * duration;
});

volumeControl.addEventListener("input", (e) => {
  let volume = e.target.value / 100;
  audio.volume = volume;
});

document.querySelectorAll(".playlist-item").forEach((item, index) => {
  item.addEventListener("click", () => {
    currentSongIndex = index;
    loadSong(currentSongIndex);
    audio.play();
  });
});

loadSong(currentSongIndex);

playPauseBtn.addEventListener("click", playPause);
prevBtn.addEventListener("click", prevSong);
nextBtn.addEventListener("click", nextSong);
